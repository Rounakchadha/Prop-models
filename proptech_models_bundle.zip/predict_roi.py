import joblib
import numpy as np
``
# Load the trained model and encoder
model = joblib.load('roi_model/roi_model.pkl')
encoder = joblib.load('roi_model/locality_encoder.pkl')

# Input from user
locality_input = input("Enter locality: ").strip().lower()
try:
    price_input = float(input("Enter property price (in INR): "))
except ValueError:
    print("❌ Invalid price. Please enter a numeric value.")
    exit()

# Check and encode locality
if locality_input not in encoder.classes_:
    print(f"❌ '{locality_input}' not recognized. Try one of these:\n{sorted(list(encoder.classes_))}")
else:
    locality_encoded = encoder.transform([locality_input])[0]
    X_input = np.array([[locality_encoded, price_input]])
    predicted_roi = model.predict(X_input)[0]
    print(f"📈 Predicted ROI for {locality_input.title()} at ₹{price_input:,.0f} is {predicted_roi:.2f}%")